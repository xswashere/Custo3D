# Calculadora Custo 3D - Flutter App

## Funcionalidades
- Calculo completo: material, energia (kWh), desgaste/hora, mao de obra, consumiveis, margem
- Energia: consumo kWh detalhado, CO2, equivalencias
- Desgaste por hora: amortizacao + manutencao com formulas
- Comparacao de modelos: Por Peca vs Por Hora vs Por Lote
- Grafico de pizza (fl_chart)
- Exportar PDF completo (pdf + printing)
- Historico persistente (shared_preferences)
- Deslizar para eliminar no historico

## Como Compilar o APK

### Pre-requisitos
1. Instalar Flutter SDK: https://flutter.dev/docs/get-started/install
2. Instalar Android Studio + Android SDK
3. Aceitar licencas: `flutter doctor --android-licenses`

### Passos
```bash
# 1. Entrar na pasta do projeto
cd custo3d

# 2. Instalar dependencias
flutter pub get

# 3. Verificar ambiente
flutter doctor

# 4. Compilar APK debug (para testar)
flutter build apk --debug

# 5. Compilar APK release (para distribuir)
flutter build apk --release

# 6. O APK fica em:
# build/app/outputs/flutter-apk/app-release.apk

# 7. Instalar diretamente num dispositivo ligado via USB
flutter install
```

### Alternativa: Compilar online sem instalar nada
1. Criar conta gratuita em https://expo.dev (se usar React Native)
   OU usar GitHub Actions com Flutter:
   - Fazer upload deste projeto para GitHub
   - Adicionar o workflow .github/workflows/build.yml (incluido)
   - O APK e gerado automaticamente no GitHub Actions

### GitHub Actions (build automatico)
Ver ficheiro: .github/workflows/flutter_build.yml

## Estrutura do Projeto
```
lib/
  main.dart                  - Entry point
  models/projeto.dart        - Modelo de dados + calculos
  utils/app_state.dart       - Estado global (Provider)
  utils/pdf_generator.dart   - Geracao de PDF
  screens/
    home_screen.dart         - Ecra principal com tabs
    calculadora_screen.dart  - Formulario em 4 passos
    resultado_screen.dart    - Resultado + graficos + comparacao
    historico_screen.dart    - Lista de calculos guardados
```
