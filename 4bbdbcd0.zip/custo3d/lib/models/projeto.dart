
class Projeto {
  String id;
  String nome;
  DateTime data;
  String tipoMaterial;
  double precoKg;
  double gramagemUsada;
  double desperdicioPercent;
  double custoBoquilha;
  double custoConsumivel;
  double tempoImpressaoHoras;
  int numPecas;
  double tempoPreparacaoMin;
  double tempoPosProcessoMin;
  double taxaHoraria;
  double supervisaoPercent;
  double potenciaW;
  double precoKwh;
  double custoImpressora;
  double vidaUtilHoras;
  double manutencaoAnual;
  double horasUsoAno;
  double margemPercent;
  double custoEnvio;

  Projeto({
    required this.id,
    required this.nome,
    required this.data,
    this.tipoMaterial = 'PLA',
    this.precoKg = 20.0,
    this.gramagemUsada = 50.0,
    this.desperdicioPercent = 15.0,
    this.custoBoquilha = 0.05,
    this.custoConsumivel = 0.02,
    this.tempoImpressaoHoras = 3.5,
    this.numPecas = 1,
    this.tempoPreparacaoMin = 30.0,
    this.tempoPosProcessoMin = 20.0,
    this.taxaHoraria = 15.0,
    this.supervisaoPercent = 10.0,
    this.potenciaW = 200.0,
    this.precoKwh = 0.22,
    this.custoImpressora = 300.0,
    this.vidaUtilHoras = 2000.0,
    this.manutencaoAnual = 50.0,
    this.horasUsoAno = 500.0,
    this.margemPercent = 30.0,
    this.custoEnvio = 0.0,
  });

  // --- Calculos de Material ---
  double get custoMaterialPorPeca {
    final gTotal = gramagemUsada * (1 + desperdicioPercent / 100);
    return (gTotal / 1000 * precoKg) / numPecas;
  }

  // --- Calculos de Energia ---
  double get energiaKwh => (potenciaW / 1000) * tempoImpressaoHoras;
  double get custoEnergiaTotal => energiaKwh * precoKwh;
  double get custoEnergiaPorPeca => custoEnergiaTotal / numPecas;
  double get co2Gramas => energiaKwh * 233; // 233g CO2/kWh (Portugal mix)

  // --- Calculos de Desgaste por hora ---
  double get amortizacaoPorHora => vidaUtilHoras > 0 ? custoImpressora / vidaUtilHoras : 0;
  double get manutencaoPorHora => horasUsoAno > 0 ? manutencaoAnual / horasUsoAno : 0;
  double get desgastePorHora => amortizacaoPorHora + manutencaoPorHora;
  double get custoDesgastePorPeca => desgastePorHora * tempoImpressaoHoras / numPecas;

  // --- Calculos de Mao de Obra ---
  double get horasSupervPorPeca => tempoImpressaoHoras * supervisaoPercent / 100 / numPecas;
  double get horasMaoObra => tempoPreparacaoMin / 60 + tempoPosProcessoMin / 60 + horasSupervPorPeca;
  double get custoMaoObraPorPeca => horasMaoObra * taxaHoraria;

  double get custoConsumivelPorPeca => custoBoquilha + custoConsumivel;

  double get subtotalPorPeca =>
      custoMaterialPorPeca +
      custoEnergiaPorPeca +
      custoDesgastePorPeca +
      custoMaoObraPorPeca +
      custoConsumivelPorPeca +
      custoEnvio;

  double get lucroPorPeca => subtotalPorPeca * margemPercent / 100;
  double get precoFinalPorPeca => subtotalPorPeca + lucroPorPeca;
  double get precoFinalTotal => precoFinalPorPeca * numPecas;

  // --- Modelo por hora ---
  double get totalHorasTrabalho =>
      tempoImpressaoHoras + tempoPreparacaoMin / 60 + tempoPosProcessoMin / 60;
  double get custoPorHora =>
      totalHorasTrabalho > 0 ? subtotalPorPeca / totalHorasTrabalho : 0;
  double get precoPorHoraComMargem => custoPorHora * (1 + margemPercent / 100);

  Projeto copyWith({
    String? id, String? nome, DateTime? data, String? tipoMaterial,
    double? precoKg, double? gramagemUsada, double? desperdicioPercent,
    double? custoBoquilha, double? custoConsumivel, double? tempoImpressaoHoras,
    int? numPecas, double? tempoPreparacaoMin, double? tempoPosProcessoMin,
    double? taxaHoraria, double? supervisaoPercent, double? potenciaW,
    double? precoKwh, double? custoImpressora, double? vidaUtilHoras,
    double? manutencaoAnual, double? horasUsoAno, double? margemPercent,
    double? custoEnvio,
  }) => Projeto(
    id: id ?? this.id, nome: nome ?? this.nome, data: data ?? this.data,
    tipoMaterial: tipoMaterial ?? this.tipoMaterial, precoKg: precoKg ?? this.precoKg,
    gramagemUsada: gramagemUsada ?? this.gramagemUsada,
    desperdicioPercent: desperdicioPercent ?? this.desperdicioPercent,
    custoBoquilha: custoBoquilha ?? this.custoBoquilha,
    custoConsumivel: custoConsumivel ?? this.custoConsumivel,
    tempoImpressaoHoras: tempoImpressaoHoras ?? this.tempoImpressaoHoras,
    numPecas: numPecas ?? this.numPecas,
    tempoPreparacaoMin: tempoPreparacaoMin ?? this.tempoPreparacaoMin,
    tempoPosProcessoMin: tempoPosProcessoMin ?? this.tempoPosProcessoMin,
    taxaHoraria: taxaHoraria ?? this.taxaHoraria,
    supervisaoPercent: supervisaoPercent ?? this.supervisaoPercent,
    potenciaW: potenciaW ?? this.potenciaW, precoKwh: precoKwh ?? this.precoKwh,
    custoImpressora: custoImpressora ?? this.custoImpressora,
    vidaUtilHoras: vidaUtilHoras ?? this.vidaUtilHoras,
    manutencaoAnual: manutencaoAnual ?? this.manutencaoAnual,
    horasUsoAno: horasUsoAno ?? this.horasUsoAno,
    margemPercent: margemPercent ?? this.margemPercent,
    custoEnvio: custoEnvio ?? this.custoEnvio,
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'nome': nome, 'data': data.toIso8601String(),
    'tipoMaterial': tipoMaterial, 'precoKg': precoKg,
    'gramagemUsada': gramagemUsada, 'desperdicioPercent': desperdicioPercent,
    'custoBoquilha': custoBoquilha, 'custoConsumivel': custoConsumivel,
    'tempoImpressaoHoras': tempoImpressaoHoras, 'numPecas': numPecas,
    'tempoPreparacaoMin': tempoPreparacaoMin, 'tempoPosProcessoMin': tempoPosProcessoMin,
    'taxaHoraria': taxaHoraria, 'supervisaoPercent': supervisaoPercent,
    'potenciaW': potenciaW, 'precoKwh': precoKwh,
    'custoImpressora': custoImpressora, 'vidaUtilHoras': vidaUtilHoras,
    'manutencaoAnual': manutencaoAnual, 'horasUsoAno': horasUsoAno,
    'margemPercent': margemPercent, 'custoEnvio': custoEnvio,
  };

  factory Projeto.fromJson(Map<String, dynamic> j) => Projeto(
    id: j['id'], nome: j['nome'], data: DateTime.parse(j['data']),
    tipoMaterial: j['tipoMaterial'] ?? 'PLA',
    precoKg: (j['precoKg'] ?? 20.0).toDouble(),
    gramagemUsada: (j['gramagemUsada'] ?? 50.0).toDouble(),
    desperdicioPercent: (j['desperdicioPercent'] ?? 15.0).toDouble(),
    custoBoquilha: (j['custoBoquilha'] ?? 0.05).toDouble(),
    custoConsumivel: (j['custoConsumivel'] ?? 0.02).toDouble(),
    tempoImpressaoHoras: (j['tempoImpressaoHoras'] ?? 3.5).toDouble(),
    numPecas: (j['numPecas'] ?? 1).toInt(),
    tempoPreparacaoMin: (j['tempoPreparacaoMin'] ?? 30.0).toDouble(),
    tempoPosProcessoMin: (j['tempoPosProcessoMin'] ?? 20.0).toDouble(),
    taxaHoraria: (j['taxaHoraria'] ?? 15.0).toDouble(),
    supervisaoPercent: (j['supervisaoPercent'] ?? 10.0).toDouble(),
    potenciaW: (j['potenciaW'] ?? 200.0).toDouble(),
    precoKwh: (j['precoKwh'] ?? 0.22).toDouble(),
    custoImpressora: (j['custoImpressora'] ?? 300.0).toDouble(),
    vidaUtilHoras: (j['vidaUtilHoras'] ?? 2000.0).toDouble(),
    manutencaoAnual: (j['manutencaoAnual'] ?? 50.0).toDouble(),
    horasUsoAno: (j['horasUsoAno'] ?? 500.0).toDouble(),
    margemPercent: (j['margemPercent'] ?? 30.0).toDouble(),
    custoEnvio: (j['custoEnvio'] ?? 0.0).toDouble(),
  );
}
