
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../utils/app_state.dart';
import '../models/projeto.dart';
import 'resultado_screen.dart';

class HistoricoScreen extends StatelessWidget {
  const HistoricoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final hist  = state.historico;
    final fmtD  = DateFormat('dd/MM/yyyy HH:mm', 'pt_PT');

    if (hist.isEmpty) {
      return const Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.inbox_outlined, size: 64, color: Colors.grey),
          SizedBox(height: 12),
          Text('Nenhum calculo guardado ainda.',
              style: TextStyle(color: Colors.grey, fontSize: 15)),
          SizedBox(height: 6),
          Text('Calcula e carrega em "Guardar" para ver aqui.',
              style: TextStyle(color: Colors.grey, fontSize: 12)),
        ]),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: hist.length,
      itemBuilder: (ctx, i) {
        final p = hist[i];
        return Dismissible(
          key: Key(p.id),
          direction: DismissDirection.endToStart,
          background: Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 20),
            decoration: BoxDecoration(
                color: Colors.red[400],
                borderRadius: BorderRadius.circular(14)),
            child: const Icon(Icons.delete_outline, color: Colors.white, size: 28),
          ),
          onDismissed: (_) => state.eliminar(p.id),
          child: Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              leading: CircleAvatar(
                backgroundColor: const Color(0xFFFF6B35).withOpacity(0.15),
                child: Text(p.tipoMaterial.substring(0, 1),
                    style: const TextStyle(
                        color: Color(0xFFFF6B35), fontWeight: FontWeight.w800)),
              ),
              title: Text(p.nome,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 3),
                  Text('${p.tipoMaterial} • ${p.numPecas}x pecas • ${fmtD.format(p.data)}',
                      style: const TextStyle(fontSize: 12)),
                  Text('Custo base: EUR ${p.subtotalPorPeca.toStringAsFixed(2)}',
                      style: const TextStyle(fontSize: 11, color: Colors.grey)),
                ],
              ),
              trailing: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('EUR ${p.precoFinalPorPeca.toStringAsFixed(2)}',
                      style: const TextStyle(
                          color: Color(0xFFFF6B35),
                          fontWeight: FontWeight.w800,
                          fontSize: 16)),
                  Text('/peca',
                      style: TextStyle(fontSize: 10, color: Colors.grey[500])),
                ],
              ),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => ResultadoScreen(projeto: p)),
              ),
            ),
          ),
        );
      },
    );
  }
}
