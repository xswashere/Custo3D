
import 'package:flutter/material.dart';
import 'calculadora_screen.dart';
import 'historico_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static const kOrange = Color(0xFFFF6B35);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: const Color(0xFFF0F2F5),
        appBar: AppBar(
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFFF6B35), Color(0xFFFF8C42)],
              ),
            ),
          ),
          foregroundColor: Colors.white,
          title: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Calculadora Custo 3D',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              Text('FDM / Resina  |  Preco justo e rentavel',
                  style: TextStyle(fontSize: 10, color: Colors.white70)),
            ],
          ),
          bottom: const TabBar(
            indicatorColor: Colors.white,
            indicatorWeight: 3,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white54,
            tabs: [
              Tab(icon: Icon(Icons.calculate_outlined), text: 'Calcular'),
              Tab(icon: Icon(Icons.history_outlined), text: 'Historico'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            CalculadoraScreen(),
            HistoricoScreen(),
          ],
        ),
      ),
    );
  }
}
