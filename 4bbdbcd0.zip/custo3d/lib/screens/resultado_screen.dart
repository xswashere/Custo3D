
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/projeto.dart';
import '../utils/app_state.dart';
import '../utils/pdf_generator.dart';

class ResultadoScreen extends StatefulWidget {
  final Projeto projeto;
  const ResultadoScreen({super.key, required this.projeto});
  @override
  State<ResultadoScreen> createState() => _ResultadoScreenState();
}

class _ResultadoScreenState extends State<ResultadoScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;

  static const kOrange = Color(0xFFFF6B35);
  static const kDark   = Color(0xFF2C3E50);
  static const kGold   = Color(0xFFFFD700);

  Projeto get p => widget.projeto;

  String _fmt(double v) => 'EUR ${v.toStringAsFixed(2).replaceAll('.', ',')}';

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F2F5),
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [kDark, Color(0xFF34495E)]),
          ),
        ),
        foregroundColor: Colors.white,
        title: Text(p.nome, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        actions: [
          IconButton(
            icon: const Icon(Icons.save_outlined),
            tooltip: 'Guardar',
            onPressed: _guardar,
          ),
          IconButton(
            icon: const Icon(Icons.picture_as_pdf_outlined),
            tooltip: 'Exportar PDF',
            onPressed: () => PdfGenerator.gerarEPartilhar(p),
          ),
        ],
        bottom: TabBar(
          controller: _tabs,
          indicatorColor: kOrange,
          indicatorWeight: 3,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white54,
          tabs: const [
            Tab(icon: Icon(Icons.receipt_outlined),    text: 'Resumo'),
            Tab(icon: Icon(Icons.pie_chart_outline),   text: 'Grafico'),
            Tab(icon: Icon(Icons.compare_arrows),      text: 'Comparar'),
          ],
        ),
      ),
      body: Column(children: [
        _heroCard(),
        Expanded(
          child: TabBarView(
            controller: _tabs,
            children: [_tabResumo(), _tabGrafico(), _tabComparar()],
          ),
        ),
      ]),
      bottomNavigationBar: _bottomBar(),
    );
  }

  // ── HERO ────────────────────────────────────────────────────
  Widget _heroCard() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [kDark, Color(0xFF34495E)]),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.18),
            blurRadius: 12, offset: const Offset(0, 4))],
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('PRECO FINAL / PECA',
              style: TextStyle(color: Colors.white60, fontSize: 11, letterSpacing: 0.5)),
          Text(_fmt(p.precoFinalPorPeca),
              style: const TextStyle(color: kGold, fontSize: 30, fontWeight: FontWeight.w800)),
          Text('Custo base: ${_fmt(p.subtotalPorPeca)}',
              style: const TextStyle(color: Colors.white54, fontSize: 11)),
        ]),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('${p.numPecas}x pecas',
              style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text('Total: ${_fmt(p.precoFinalTotal)}',
              style: const TextStyle(color: kGold, fontWeight: FontWeight.w700, fontSize: 13)),
          const SizedBox(height: 4),
          Text('Lucro: ${_fmt(p.lucroPorPeca)}',
              style: const TextStyle(color: Colors.greenAccent, fontSize: 12)),
        ]),
      ]),
    );
  }

  // ── TAB 1: RESUMO ────────────────────────────────────────────
  Widget _tabResumo() {
    final itens = [
      _CustoItem('Material',    p.custoMaterialPorPeca,   const Color(0xFFFF6B35)),
      _CustoItem('Mao de Obra', p.custoMaoObraPorPeca,    const Color(0xFFE74C3C)),
      _CustoItem('Energia',     p.custoEnergiaPorPeca,    const Color(0xFFF39C12)),
      _CustoItem('Desgaste',    p.custoDesgastePorPeca,   const Color(0xFF9B59B6)),
      _CustoItem('Consumiveis', p.custoConsumivelPorPeca, const Color(0xFF1ABC9C)),
      _CustoItem('Envio/Embal.', p.custoEnvio,            const Color(0xFF3498DB)),
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Barra por item
        Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          child: Column(children: [
            ...itens.map((i) => _barItem(i)),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.trending_up, color: kOrange),
              title: Text('Lucro (${p.margemPercent.toStringAsFixed(0)}%)',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              trailing: Text(_fmt(p.lucroPorPeca),
                  style: const TextStyle(color: kOrange, fontWeight: FontWeight.w800, fontSize: 15)),
            ),
          ]),
        ),

        const SizedBox(height: 12),

        // Detalhe Energia
        _sectionCard('Detalhe de Energia (kWh)', Icons.bolt, [
          _fmtRow('Potencia', '${p.potenciaW.toStringAsFixed(0)} W'),
          _fmtRow('Tempo impressao', '${p.tempoImpressaoHoras.toStringAsFixed(1)} h'),
          _divider(),
          _formulaRow(
            'Consumo da impressao',
            '${p.energiaKwh.toStringAsFixed(4)} kWh',
            '(${p.potenciaW.toStringAsFixed(0)} W / 1000) x ${p.tempoImpressaoHoras.toStringAsFixed(1)} h',
            kOrange,
          ),
          _fmtRow('Preco energia', '${p.precoKwh.toStringAsFixed(3)} EUR/kWh'),
          _divider(),
          _formulaRow(
            'Custo energia total (lote)',
            'EUR ${p.custoEnergiaTotal.toStringAsFixed(4)}',
            '${p.energiaKwh.toStringAsFixed(4)} kWh x ${p.precoKwh.toStringAsFixed(3)} EUR',
            kOrange,
          ),
          _highlightRow('Custo energia / peca', 'EUR ${p.custoEnergiaPorPeca.toStringAsFixed(4)}', Colors.green),
          _fmtRow('CO2 emitido', '${p.co2Gramas.toStringAsFixed(1)} g CO2'),
        ]),

        const SizedBox(height: 12),

        // Detalhe Desgaste
        _sectionCard('Desgaste e Manutencao por Hora', Icons.build_circle_outlined, [
          _formulaRow(
            'Amortizacao / hora',
            '${p.amortizacaoPorHora.toStringAsFixed(5)} EUR/h',
            'EUR ${p.custoImpressora.toStringAsFixed(0)} / ${p.vidaUtilHoras.toStringAsFixed(0)} h',
            Colors.purple,
          ),
          _formulaRow(
            'Manutencao / hora',
            '${p.manutencaoPorHora.toStringAsFixed(5)} EUR/h',
            'EUR ${p.manutencaoAnual.toStringAsFixed(0)} / ${p.horasUsoAno.toStringAsFixed(0)} h',
            Colors.purple,
          ),
          _highlightRow('Desgaste total / hora', '${p.desgastePorHora.toStringAsFixed(5)} EUR/h', Colors.purple),
          _highlightRow('Custo desgaste / peca', 'EUR ${p.custoDesgastePorPeca.toStringAsFixed(4)}', Colors.deepPurple),
        ]),
      ],
    );
  }

  Widget _barItem(_CustoItem item) {
    final pct = p.subtotalPorPeca > 0 ? item.valor / p.subtotalPorPeca : 0.0;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(item.label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
          Row(children: [
            Text(_fmt(item.valor),
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            const SizedBox(width: 6),
            Text('(${(pct * 100).toStringAsFixed(1)}%)',
                style: const TextStyle(fontSize: 11, color: Colors.grey)),
          ]),
        ]),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: pct,
            minHeight: 8,
            backgroundColor: const Color(0xFFE8E8E8),
            valueColor: AlwaysStoppedAnimation(item.cor),
          ),
        ),
      ]),
    );
  }

  // ── TAB 2: GRAFICO ────────────────────────────────────────────
  Widget _tabGrafico() {
    final itens = [
      _CustoItem('Material',    p.custoMaterialPorPeca,   const Color(0xFFFF6B35)),
      _CustoItem('Mao de Obra', p.custoMaoObraPorPeca,    const Color(0xFFE74C3C)),
      _CustoItem('Energia',     p.custoEnergiaPorPeca,    const Color(0xFFF39C12)),
      _CustoItem('Desgaste',    p.custoDesgastePorPeca,   const Color(0xFF9B59B6)),
      _CustoItem('Consumiveis', p.custoConsumivelPorPeca, const Color(0xFF1ABC9C)),
      if (p.custoEnvio > 0)
        _CustoItem('Envio', p.custoEnvio, const Color(0xFF3498DB)),
    ];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              const Text('Distribuicao dos Custos por Peca',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              const SizedBox(height: 16),
              SizedBox(
                height: 220,
                child: PieChart(PieChartData(
                  sections: itens.map((i) {
                    final pct = p.subtotalPorPeca > 0
                        ? i.valor / p.subtotalPorPeca * 100
                        : 0.0;
                    return PieChartSectionData(
                      value: i.valor,
                      title: '${pct.toStringAsFixed(0)}%',
                      titleStyle: const TextStyle(
                          color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                      color: i.cor,
                      radius: 85,
                    );
                  }).toList(),
                  sectionsSpace: 2,
                  centerSpaceRadius: 32,
                )),
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 12, runSpacing: 6,
                children: itens.map((i) => Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                        width: 12, height: 12,
                        decoration: BoxDecoration(color: i.cor, shape: BoxShape.circle)),
                    const SizedBox(width: 4),
                    Text(i.label, style: const TextStyle(fontSize: 12)),
                    const SizedBox(width: 4),
                    Text(_fmt(i.valor),
                        style: const TextStyle(fontSize: 11, color: Colors.grey)),
                  ],
                )).toList(),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        // Barras de energia detalhada
        _sectionCard('Composicao Energetica', Icons.bolt, [
          _barVisual('Potencia ativa', p.potenciaW, 500, 'W', const Color(0xFFF39C12)),
          _barVisual('Consumo total', p.energiaKwh * 1000, 5000, 'Wh', const Color(0xFFE67E22)),
          _barVisual('Custo energia', p.custoEnergiaPorPeca * 100, 200, 'cts', const Color(0xFFD35400)),
        ]),
      ],
    );
  }

  Widget _barVisual(String label, double val, double max, String unit, Color cor) {
    final pct = (val / max).clamp(0.0, 1.0);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(label, style: const TextStyle(fontSize: 12)),
          Text('${val.toStringAsFixed(2)} $unit',
              style: TextStyle(fontSize: 12, color: cor, fontWeight: FontWeight.w700)),
        ]),
        const SizedBox(height: 3),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: pct, minHeight: 7,
            backgroundColor: const Color(0xFFE8E8E8),
            valueColor: AlwaysStoppedAnimation(cor),
          ),
        ),
      ]),
    );
  }

  // ── TAB 3: COMPARAR MODELOS ───────────────────────────────────
  Widget _tabComparar() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionCard('Modelos de Precificacao', Icons.compare_arrows, [
          _modeloCard(
            'Por Peca',
            _fmt(p.precoFinalPorPeca),
            'Preco unitario baseado no custo real de cada peca.',
            'Ideal para: Series, produtos definidos, lojas online.',
            kOrange,
            Icons.widgets_outlined,
          ),
          const SizedBox(height: 10),
          _modeloCard(
            'Por Hora de Trabalho',
            '${p.precoPorHoraComMargem.toStringAsFixed(2)} EUR/h',
            'Cobra pelo tempo total: impressao + preparacao + pos-processo.',
            'Ideal para: Prototipos, encomendas personalizadas, orcamentos.',
            const Color(0xFF3498DB),
            Icons.access_time_outlined,
          ),
          const SizedBox(height: 10),
          _modeloCard(
            'Por Lote (${p.numPecas}x pecas)',
            _fmt(p.precoFinalTotal),
            'Preco total para o lote completo.',
            'Ideal para: Encomendas em quantidade, desconto de volume.',
            const Color(0xFF27AE60),
            Icons.inventory_2_outlined,
          ),
        ]),
        const SizedBox(height: 12),
        _sectionCard('Detalhes do Calculo', Icons.functions, [
          _fmtRow('Total horas de trabalho', '${p.totalHorasTrabalho.toStringAsFixed(2)} h'),
          _fmtRow('Custo base / hora', '${p.custoPorHora.toStringAsFixed(4)} EUR/h'),
          _fmtRow('Custo base / peca', _fmt(p.subtotalPorPeca)),
          _fmtRow('Margem aplicada', '${p.margemPercent.toStringAsFixed(0)}%'),
          _divider(),
          _highlightRow('Preco final / peca', _fmt(p.precoFinalPorPeca), kOrange),
          _highlightRow('Preco final / hora', '${p.precoPorHoraComMargem.toStringAsFixed(2)} EUR/h',
              const Color(0xFF3498DB)),
          _highlightRow('Preco final lote', _fmt(p.precoFinalTotal), const Color(0xFF27AE60)),
        ]),
        const SizedBox(height: 12),
        _dicaCard(),
      ],
    );
  }

  Widget _modeloCard(String titulo, String valor, String desc, String uso,
      Color cor, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cor.withOpacity(0.07),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cor.withOpacity(0.35)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Row(children: [
            Icon(icon, color: cor, size: 18),
            const SizedBox(width: 6),
            Text(titulo, style: TextStyle(fontWeight: FontWeight.w700, color: cor, fontSize: 14)),
          ]),
          Text(valor, style: TextStyle(fontWeight: FontWeight.w800, color: cor, fontSize: 17)),
        ]),
        const SizedBox(height: 6),
        Text(desc, style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 3),
        Text(uso, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
      ]),
    );
  }

  Widget _dicaCard() {
    String texto;
    if (p.custoMaoObraPorPeca > p.subtotalPorPeca * 0.4) {
      texto = 'Mao de obra e mais de 40% do custo. Considera agrupar mais pecas por impressao para diluir o tempo de preparacao.';
    } else if (p.custoMaterialPorPeca > p.subtotalPorPeca * 0.5) {
      texto = 'O material e mais de 50% do custo. Reduzir suportes ou usar filamento mais economico pode aumentar significativamente a margem.';
    } else if (p.custoDesgastePorPeca > p.subtotalPorPeca * 0.2) {
      texto = 'O desgaste do equipamento representa mais de 20% do custo. Aumentar o volume de impressoes por ano reduz o custo unitario.';
    } else {
      texto = 'Boa distribuicao de custos! O modelo por peca e o mais adequado para este projeto. Considera aumentar a margem gradualmente.';
    }
    return Card(
      color: const Color(0xFFE8F8F0),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Color(0xFF27AE60), width: 1.5)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [
            Icon(Icons.lightbulb_outline, color: Color(0xFF27AE60), size: 18),
            SizedBox(width: 6),
            Text('Recomendacao', style: TextStyle(
                fontWeight: FontWeight.w700, color: Color(0xFF27AE60), fontSize: 13)),
          ]),
          const SizedBox(height: 8),
          Text(texto, style: const TextStyle(fontSize: 13, color: Color(0xFF1D6A40))),
        ]),
      ),
    );
  }

  // ── BOTTOM BAR ───────────────────────────────────────────────
  Widget _bottomBar() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
        child: Row(children: [
          Expanded(
            child: OutlinedButton.icon(
              icon: const Icon(Icons.picture_as_pdf, color: kOrange),
              label: const Text('Exportar PDF', style: TextStyle(color: kOrange)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: kOrange),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () => PdfGenerator.gerarEPartilhar(p),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: FilledButton.icon(
              icon: const Icon(Icons.share),
              label: const Text('Copiar'),
              style: FilledButton.styleFrom(
                backgroundColor: kOrange,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: _copiarResultado,
            ),
          ),
        ]),
      ),
    );
  }

  // ── HELPERS ───────────────────────────────────────────────────
  Widget _sectionCard(String title, IconData icon, List<Widget> children) =>
      Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(icon, color: kOrange, size: 18),
              const SizedBox(width: 6),
              Text(title.toUpperCase(),
                  style: const TextStyle(color: kOrange, fontWeight: FontWeight.w700,
                      fontSize: 12, letterSpacing: 0.5)),
            ]),
            const SizedBox(height: 12),
            ...children,
          ]),
        ),
      );

  Widget _fmtRow(String label, String value, {bool bold = false}) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(label, style: TextStyle(fontSize: 13, color: Colors.grey[700])),
          Text(value, style: TextStyle(
              fontSize: 13,
              fontWeight: bold ? FontWeight.w700 : FontWeight.w600,
              color: bold ? kDark : Colors.black87)),
        ]),
      );

  Widget _formulaRow(String label, String value, String formula, Color cor) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            Text(value, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: cor)),
          ]),
          Text(formula, style: TextStyle(fontSize: 10, color: Colors.grey[500])),
        ]),
      );

  Widget _highlightRow(String label, String value, Color cor) =>
      Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: cor.withOpacity(0.08),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: cor.withOpacity(0.3)),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(label, style: TextStyle(fontSize: 13, color: cor, fontWeight: FontWeight.w600)),
          Text(value, style: TextStyle(fontSize: 14, color: cor, fontWeight: FontWeight.w800)),
        ]),
      );

  Widget _divider() => const Padding(
      padding: EdgeInsets.symmetric(vertical: 4), child: Divider(height: 1));

  // ── ACOES ─────────────────────────────────────────────────────
  void _guardar() async {
    await context.read<AppState>().guardar();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Guardado no historico!'),
            backgroundColor: Color(0xFF27AE60)),
      );
    }
  }

  void _copiarResultado() {
    final txt = '''
CUSTO IMPRESSAO 3D - ${p.nome}
==============================
Preco Final/Peca : ${_fmt(p.precoFinalPorPeca)}
Custo Base/Peca  : ${_fmt(p.subtotalPorPeca)}
Lucro (${p.margemPercent.toStringAsFixed(0)}%)     : ${_fmt(p.lucroPorPeca)}
Total (${p.numPecas}x pecas)  : ${_fmt(p.precoFinalTotal)}

DECOMPOSICAO:
  Material    : ${_fmt(p.custoMaterialPorPeca)}
  Mao de Obra : ${_fmt(p.custoMaoObraPorPeca)}
  Energia     : ${_fmt(p.custoEnergiaPorPeca)} (${p.energiaKwh.toStringAsFixed(3)} kWh)
  Desgaste    : ${_fmt(p.custoDesgastePorPeca)} (${p.desgastePorHora.toStringAsFixed(5)} EUR/h)
  Consumiveis : ${_fmt(p.custoConsumivelPorPeca)}
  Envio       : ${_fmt(p.custoEnvio)}

MODELOS ALTERNATIVOS:
  Por hora    : ${p.precoPorHoraComMargem.toStringAsFixed(2)} EUR/h
  Por lote    : ${_fmt(p.precoFinalTotal)}

Calculado com Calculadora Custo 3D
''';
    Clipboard.setData(ClipboardData(text: txt));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Copiado para clipboard!')),
    );
  }
}

class _CustoItem {
  final String label;
  final double valor;
  final Color cor;
  const _CustoItem(this.label, this.valor, this.cor);
}
