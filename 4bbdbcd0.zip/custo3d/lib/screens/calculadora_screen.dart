
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/projeto.dart';
import '../utils/app_state.dart';
import 'resultado_screen.dart';

class CalculadoraScreen extends StatefulWidget {
  const CalculadoraScreen({super.key});
  @override
  State<CalculadoraScreen> createState() => _CalculadoraScreenState();
}

class _CalculadoraScreenState extends State<CalculadoraScreen> {
  int _step = 0;
  late Projeto _p;

  static const kOrange = Color(0xFFFF6B35);
  static const kDark = Color(0xFF2C3E50);

  static const _presets = {
    'PLA':    {'precoKg': 20.0, 'potenciaW': 180.0},
    'PETG':   {'precoKg': 24.0, 'potenciaW': 200.0},
    'ABS':    {'precoKg': 22.0, 'potenciaW': 220.0},
    'TPU':    {'precoKg': 30.0, 'potenciaW': 190.0},
    'Resina': {'precoKg': 35.0, 'potenciaW': 65.0},
  };

  @override
  void initState() {
    super.initState();
    _p = context.read<AppState>().atual;
  }

  void _save(Projeto p) {
    setState(() => _p = p);
    context.read<AppState>().atualizar(p);
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context).copyWith(
        colorScheme: ColorScheme.fromSeed(seedColor: kOrange),
      ),
      child: Stepper(
        type: StepperType.horizontal,
        currentStep: _step,
        onStepTapped: (s) => setState(() => _step = s),
        controlsBuilder: (ctx, details) => Padding(
          padding: const EdgeInsets.only(top: 14),
          child: Row(children: [
            if (_step < 3)
              Expanded(
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: kOrange,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: () => setState(() => _step++),
                  child: const Text('Proximo', style: TextStyle(fontSize: 15)),
                ),
              ),
            if (_step == 3)
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: kDark,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: _verResultado,
                  icon: const Icon(Icons.bar_chart),
                  label: const Text('VER RESULTADO', style: TextStyle(fontSize: 15)),
                ),
              ),
            if (_step > 0) ...[
              const SizedBox(width: 8),
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: () => setState(() => _step--),
                child: const Icon(Icons.arrow_back),
              ),
            ],
          ]),
        ),
        steps: [
          Step(
            title: const Text('Material'),
            isActive: _step >= 0,
            state: _step > 0 ? StepState.complete : StepState.indexed,
            content: _buildMaterial(),
          ),
          Step(
            title: const Text('Impressao'),
            isActive: _step >= 1,
            state: _step > 1 ? StepState.complete : StepState.indexed,
            content: _buildImpressao(),
          ),
          Step(
            title: const Text('Energia'),
            isActive: _step >= 2,
            state: _step > 2 ? StepState.complete : StepState.indexed,
            content: _buildEnergia(),
          ),
          Step(
            title: const Text('Custos'),
            isActive: _step >= 3,
            state: StepState.indexed,
            content: _buildCustos(),
          ),
        ],
      ),
    );
  }

  void _verResultado() {
    Navigator.push(context,
        MaterialPageRoute(builder: (_) => ResultadoScreen(projeto: _p)));
  }

  // ---- STEP 0: MATERIAL ----------------------------------------
  Widget _buildMaterial() {
    return Column(children: [
      _card('Projeto', Icons.label_outline, [
        _txtField('Nome do Projeto', _p.nome, (v) => _save(_p.copyWith(nome: v))),
      ]),
      _card('Tipo de Material', Icons.layers_outlined, [
        Wrap(
          spacing: 8, runSpacing: 8,
          children: _presets.keys.map((tipo) {
            final sel = _p.tipoMaterial == tipo;
            return ChoiceChip(
              label: Text(tipo, style: TextStyle(
                color: sel ? Colors.white : Colors.black87,
                fontWeight: FontWeight.w600,
              )),
              selected: sel,
              selectedColor: kOrange,
              backgroundColor: const Color(0xFFF0F2F5),
              onSelected: (_) {
                final pr = _presets[tipo]!;
                _save(_p.copyWith(
                  tipoMaterial: tipo,
                  precoKg: pr['precoKg'],
                  potenciaW: pr['potenciaW'],
                ));
              },
            );
          }).toList(),
        ),
        const SizedBox(height: 12),
        _row2(
          _numField('Preco por kg (EUR)', _p.precoKg, (v) => _save(_p.copyWith(precoKg: v))),
          _numField('Gramagem usada (g)', _p.gramagemUsada, (v) => _save(_p.copyWith(gramagemUsada: v))),
        ),
        _sliderRow('Desperdicio / Suportes', _p.desperdicioPercent, 0, 50, '%',
            'Brim, suportes, falhas, purgacoes',
            (v) => _save(_p.copyWith(desperdicioPercent: v))),
      ]),
      _card('Consumiveis', Icons.build_outlined, [
        _row2(
          _numField('Boquilha / nozzle (EUR)', _p.custoBoquilha,
              (v) => _save(_p.copyWith(custoBoquilha: v)), dec: 3),
          _numField('Cola / adesivos (EUR)', _p.custoConsumivel,
              (v) => _save(_p.copyWith(custoConsumivel: v)), dec: 3),
        ),
      ]),
    ]);
  }

  // ---- STEP 1: IMPRESSAO ---------------------------------------
  Widget _buildImpressao() {
    return Column(children: [
      _card('Tempos de Impressao', Icons.timer_outlined, [
        _row2(
          _numField('Tempo impressao (h)', _p.tempoImpressaoHoras,
              (v) => _save(_p.copyWith(tempoImpressaoHoras: v))),
          _numField('Num. de pecas', _p.numPecas.toDouble(),
              (v) => _save(_p.copyWith(numPecas: v.toInt())), isInt: true),
        ),
        _row2(
          _numField('Preparacao / fatiamento (min)', _p.tempoPreparacaoMin,
              (v) => _save(_p.copyWith(tempoPreparacaoMin: v))),
          _numField('Pos-processamento (min)', _p.tempoPosProcessoMin,
              (v) => _save(_p.copyWith(tempoPosProcessoMin: v))),
        ),
        _hint('Pos-processo: limpeza, cura UV, lixagem, pintura, montagem...'),
      ]),
      _card('Mao de Obra', Icons.person_outline, [
        _numField('Taxa horaria (EUR/h)', _p.taxaHoraria,
            (v) => _save(_p.copyWith(taxaHoraria: v))),
        _sliderRow('Supervisao durante impressao', _p.supervisaoPercent, 0, 100, '%',
            '% do tempo de impressao com presenca fisica necessaria',
            (v) => _save(_p.copyWith(supervisaoPercent: v))),
      ]),
    ]);
  }

  // ---- STEP 2: ENERGIA -----------------------------------------
  Widget _buildEnergia() {
    final kwh = _p.energiaKwh;
    final custoTotal = _p.custoEnergiaTotal;
    final custoPeca = _p.custoEnergiaPorPeca;
    final co2 = _p.co2Gramas;
    final custoMes = (kwh / (_p.tempoImpressaoHoras > 0 ? _p.tempoImpressaoHoras : 1)) * 8 * 30 * _p.precoKwh;

    return Column(children: [
      _card('Parametros Eletricos', Icons.bolt_outlined, [
        _row2(
          _numField('Potencia da impressora (W)', _p.potenciaW,
              (v) => _save(_p.copyWith(potenciaW: v)), dec: 0),
          _numField('Preco energia (EUR/kWh)', _p.precoKwh,
              (v) => _save(_p.copyWith(precoKwh: v)), dec: 3),
        ),
        _hint('Portugal: ~0.20-0.25 EUR/kWh  |  FDM: 150-300W  |  Resina MSLA: 50-80W'),
      ]),
      _card('Calculo Detalhado de Energia', Icons.calculate_outlined, [
        _infoLine('Potencia da impressora', '${_p.potenciaW.toStringAsFixed(0)} W'),
        _infoLine('Tempo de impressao', '${_p.tempoImpressaoHoras.toStringAsFixed(1)} h'),
        const Divider(),
        _formulaLine(
          'Consumo por impressao',
          '${kwh.toStringAsFixed(4)} kWh',
          '(${_p.potenciaW.toStringAsFixed(0)}W / 1000) x ${_p.tempoImpressaoHoras.toStringAsFixed(1)}h',
          kOrange,
        ),
        _infoLine('Preco por kWh', '${_p.precoKwh.toStringAsFixed(3)} EUR'),
        const Divider(),
        _formulaLine(
          'Custo energia (lote ${_p.numPecas}x)',
          'EUR ${custoTotal.toStringAsFixed(4)}',
          '${kwh.toStringAsFixed(4)} kWh x ${_p.precoKwh.toStringAsFixed(3)} EUR',
          kOrange,
        ),
        _highlightLine('Custo energia por peca', 'EUR ${custoPeca.toStringAsFixed(4)}', Colors.green),
      ]),
      _card('Equivalencias', Icons.info_outline, [
        _infoLine('CO2 emitido', '${co2.toStringAsFixed(1)} g CO2'),
        _infoLine('Custo estimado 8h/dia (30 dias)', 'EUR ${custoMes.toStringAsFixed(2)}'),
        _infoLine('Equiv. carregadores telemovel', '${(kwh / 0.005).toStringAsFixed(0)} cargas'),
      ]),
    ]);
  }

  // ---- STEP 3: CUSTOS / DESGASTE / MARGEM ----------------------
  Widget _buildCustos() {
    final amortH = _p.amortizacaoPorHora;
    final manutH = _p.manutencaoPorHora;
    final desgH = _p.desgastePorHora;
    final desgPeca = _p.custoDesgastePorPeca;

    return Column(children: [
      _card('Desgaste e Manutencao por Hora', Icons.build_circle_outlined, [
        _numField('Custo da impressora (EUR)', _p.custoImpressora,
            (v) => _save(_p.copyWith(custoImpressora: v)), dec: 0),
        _row2(
          _numField('Vida util (horas)', _p.vidaUtilHoras,
              (v) => _save(_p.copyWith(vidaUtilHoras: v)), dec: 0),
          _numField('Manutencao anual (EUR)', _p.manutencaoAnual,
              (v) => _save(_p.copyWith(manutencaoAnual: v)), dec: 0),
        ),
        _numField('Horas de uso por ano', _p.horasUsoAno,
            (v) => _save(_p.copyWith(horasUsoAno: v)), dec: 0),
        const Divider(),
        _formulaLine('Amortizacao/hora', '${amortH.toStringAsFixed(5)} EUR/h',
            'EUR${_p.custoImpressora.toStringAsFixed(0)} / ${_p.vidaUtilHoras.toStringAsFixed(0)}h', Colors.purple),
        _formulaLine('Manutencao/hora', '${manutH.toStringAsFixed(5)} EUR/h',
            'EUR${_p.manutencaoAnual.toStringAsFixed(0)} / ${_p.horasUsoAno.toStringAsFixed(0)}h', Colors.purple),
        _highlightLine('Desgaste total/hora', '${desgH.toStringAsFixed(5)} EUR/h', Colors.purple),
        _highlightLine('Custo desgaste por peca', 'EUR ${desgPeca.toStringAsFixed(4)}', Colors.deepPurple),
      ]),
      _card('Margem e Envio', Icons.trending_up_outlined, [
        _sliderRow('Margem de lucro', _p.margemPercent, 0, 200, '%', '',
            (v) => _save(_p.copyWith(margemPercent: v))),
        _numField('Embalagem / Envio (EUR)', _p.custoEnvio,
            (v) => _save(_p.copyWith(custoEnvio: v))),
      ]),
    ]);
  }

  // ---- WIDGETS HELPER ------------------------------------------
  Widget _card(String title, IconData icon, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(icon, color: kOrange, size: 18),
            const SizedBox(width: 6),
            Text(title.toUpperCase(),
                style: const TextStyle(
                    color: kOrange, fontWeight: FontWeight.w700,
                    fontSize: 12, letterSpacing: 0.5)),
          ]),
          const SizedBox(height: 12),
          ...children,
        ]),
      ),
    );
  }

  Widget _txtField(String label, String val, ValueChanged<String> cb) =>
      TextField(
        controller: TextEditingController(text: val)
          ..selection = TextSelection.collapsed(offset: val.length),
        decoration: InputDecoration(labelText: label),
        onChanged: cb,
      );

  Widget _numField(String label, double val, ValueChanged<double> cb,
      {int dec = 2, bool isInt = false}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          controller: TextEditingController(
              text: isInt ? val.toInt().toString() : val.toStringAsFixed(dec)),
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: label),
          onChanged: (s) {
            final v = double.tryParse(s.replaceAll(',', '.'));
            if (v != null) cb(v);
          },
        ),
      );

  Widget _row2(Widget a, Widget b) =>
      Row(children: [
        Expanded(child: a),
        const SizedBox(width: 10),
        Expanded(child: b),
      ]);

  Widget _sliderRow(String label, double val, double min, double max,
      String suffix, String hint, ValueChanged<double> cb) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
          decoration: BoxDecoration(color: kOrange, borderRadius: BorderRadius.circular(20)),
          child: Text('${val.toStringAsFixed(0)}$suffix',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
        ),
      ]),
      Slider(
        value: val, min: min, max: max,
        divisions: (max - min).toInt(),
        activeColor: kOrange,
        onChanged: cb,
      ),
      if (hint.isNotEmpty) _hint(hint),
    ]);
  }

  Widget _infoLine(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: TextStyle(fontSize: 13, color: Colors.grey[700])),
      Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
    ]),
  );

  Widget _formulaLine(String label, String value, String formula, Color color) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            Text(value, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: color)),
          ]),
          Text(formula, style: TextStyle(fontSize: 10, color: Colors.grey[500])),
        ]),
      );

  Widget _highlightLine(String label, String value, Color color) => Container(
    margin: const EdgeInsets.symmetric(vertical: 4),
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
    decoration: BoxDecoration(
      color: color.withOpacity(0.08),
      borderRadius: BorderRadius.circular(8),
      border: Border.all(color: color.withOpacity(0.3)),
    ),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: TextStyle(fontSize: 13, color: color, fontWeight: FontWeight.w600)),
      Text(value, style: TextStyle(fontSize: 13, color: color, fontWeight: FontWeight.w800)),
    ]),
  );

  Widget _hint(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(text, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
  );
}
