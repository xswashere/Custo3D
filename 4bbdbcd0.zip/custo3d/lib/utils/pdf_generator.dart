
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../models/projeto.dart';

class PdfGenerator {
  static Future<void> gerarEPartilhar(Projeto p) async {
    final doc     = pw.Document();
    final fmt     = NumberFormat.currency(locale: 'pt_PT', symbol: 'EUR ', decimalDigits: 2);
    final fmtDate = DateFormat('dd/MM/yyyy HH:mm');
    final cOrange = PdfColor.fromHex('#FF6B35');
    final cDark   = PdfColor.fromHex('#2C3E50');
    final cGold   = PdfColor.fromHex('#FFD700');
    final cGrey   = PdfColor.fromHex('#7F8C8D');
    final cLight  = PdfColor.fromHex('#F0F2F5');
    final cPurple = PdfColor.fromHex('#9B59B6');
    final cGreen  = PdfColor.fromHex('#27AE60');

    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(36),
      build: (ctx) => [

        // ── CABECALHO ──────────────────────────────────────
        pw.Container(
          padding: const pw.EdgeInsets.all(16),
          decoration: pw.BoxDecoration(
              color: cOrange, borderRadius: pw.BorderRadius.circular(8)),
          child: pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                pw.Text('RELATORIO DE CUSTO IMPRESSAO 3D',
                    style: pw.TextStyle(color: PdfColors.white, fontSize: 16,
                        fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 4),
                pw.Text(p.nome,
                    style: pw.TextStyle(color: PdfColors.white, fontSize: 12)),
              ]),
              pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
                pw.Text(fmtDate.format(p.data),
                    style: pw.TextStyle(color: PdfColors.white, fontSize: 9)),
                pw.SizedBox(height: 4),
                pw.Text('Material: ${p.tipoMaterial}  |  ${p.numPecas}x pecas',
                    style: pw.TextStyle(color: PdfColors.white, fontSize: 9)),
              ]),
            ],
          ),
        ),
        pw.SizedBox(height: 16),

        // ── PRECO DESTAQUE ─────────────────────────────────
        pw.Container(
          padding: const pw.EdgeInsets.all(16),
          decoration: pw.BoxDecoration(
              color: cDark, borderRadius: pw.BorderRadius.circular(8)),
          child: pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                pw.Text('PRECO FINAL POR PECA',
                    style: pw.TextStyle(color: PdfColors.white, fontSize: 10)),
                pw.Text(fmt.format(p.precoFinalPorPeca),
                    style: pw.TextStyle(color: cGold, fontSize: 26,
                        fontWeight: pw.FontWeight.bold)),
                pw.Text('Custo base: ${fmt.format(p.subtotalPorPeca)}  |  Lucro: ${fmt.format(p.lucroPorPeca)}',
                    style: pw.TextStyle(color: PdfColors.grey, fontSize: 9)),
              ]),
              pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
                pw.Text('${p.numPecas}x pecas',
                    style: pw.TextStyle(color: PdfColors.white, fontSize: 11,
                        fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 4),
                pw.Text('Total: ${fmt.format(p.precoFinalTotal)}',
                    style: pw.TextStyle(color: cGold, fontSize: 13,
                        fontWeight: pw.FontWeight.bold)),
              ]),
            ],
          ),
        ),
        pw.SizedBox(height: 18),

        // ── DECOMPOSICAO ───────────────────────────────────
        pw.Text('DECOMPOSICAO DOS CUSTOS',
            style: pw.TextStyle(color: cDark, fontSize: 12,
                fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 8),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey300, width: 0.5),
          columnWidths: {
            0: const pw.FlexColumnWidth(3),
            1: const pw.FlexColumnWidth(2),
            2: const pw.FlexColumnWidth(1.5),
          },
          children: [
            // header
            pw.TableRow(
              decoration: pw.BoxDecoration(color: cOrange),
              children: [_th('ITEM', PdfColors.white), _th('VALOR / PECA', PdfColors.white),
                         _th('% DO CUSTO', PdfColors.white)],
            ),
            ...[
              ['Material',    fmt.format(p.custoMaterialPorPeca),   _pct(p.custoMaterialPorPeca, p.subtotalPorPeca)],
              ['Mao de Obra', fmt.format(p.custoMaoObraPorPeca),    _pct(p.custoMaoObraPorPeca, p.subtotalPorPeca)],
              ['Energia',     fmt.format(p.custoEnergiaPorPeca),    _pct(p.custoEnergiaPorPeca, p.subtotalPorPeca)],
              ['Desgaste',    fmt.format(p.custoDesgastePorPeca),   _pct(p.custoDesgastePorPeca, p.subtotalPorPeca)],
              ['Consumiveis', fmt.format(p.custoConsumivelPorPeca), _pct(p.custoConsumivelPorPeca, p.subtotalPorPeca)],
              ['Envio/Embal.',fmt.format(p.custoEnvio),             _pct(p.custoEnvio, p.subtotalPorPeca)],
            ].asMap().entries.map((e) => pw.TableRow(
              decoration: e.key.isOdd ? pw.BoxDecoration(color: cLight) : null,
              children: e.value.map((c) => _td(c)).toList(),
            )),
            pw.TableRow(
              decoration: pw.BoxDecoration(color: PdfColor.fromHex('#FFF3EE')),
              children: [
                _tdBold('Lucro (${p.margemPercent.toStringAsFixed(0)}%)', cOrange),
                _tdBold(fmt.format(p.lucroPorPeca), cOrange),
                _tdBold('${p.margemPercent.toStringAsFixed(0)}%', cOrange),
              ],
            ),
            pw.TableRow(
              decoration: pw.BoxDecoration(color: cDark),
              children: [
                _tdBold('PRECO FINAL / PECA', PdfColors.white),
                _tdBold(fmt.format(p.precoFinalPorPeca), cGold),
                _td(''),
              ],
            ),
          ],
        ),
        pw.SizedBox(height: 18),

        // ── ENERGIA DETALHADA ──────────────────────────────
        pw.Text('ANALISE DETALHADA DE ENERGIA (kWh)',
            style: pw.TextStyle(color: cDark, fontSize: 12,
                fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        pw.Container(
          padding: const pw.EdgeInsets.all(12),
          decoration: pw.BoxDecoration(color: cLight, borderRadius: pw.BorderRadius.circular(6)),
          child: pw.Column(children: [
            _infoRow('Potencia da impressora', '${p.potenciaW.toStringAsFixed(0)} W', cGrey),
            _infoRow('Tempo de impressao', '${p.tempoImpressaoHoras.toStringAsFixed(1)} h', cGrey),
            _infoRow('Formula consumo', '(${p.potenciaW.toStringAsFixed(0)} W / 1000) x ${p.tempoImpressaoHoras.toStringAsFixed(1)} h', cGrey),
            _infoRow('Consumo por impressao', '${p.energiaKwh.toStringAsFixed(4)} kWh', cOrange, bold: true),
            _infoRow('Preco energia', '${p.precoKwh.toStringAsFixed(3)} EUR/kWh', cGrey),
            _infoRow('Custo energia total (lote)', fmt.format(p.custoEnergiaTotal), cOrange, bold: true),
            _infoRow('Custo energia por peca', fmt.format(p.custoEnergiaPorPeca), cGreen, bold: true),
            _infoRow('CO2 emitido', '${p.co2Gramas.toStringAsFixed(1)} g CO2', cGrey),
          ]),
        ),
        pw.SizedBox(height: 14),

        // ── DESGASTE ───────────────────────────────────────
        pw.Text('DESGASTE E MANUTENCAO POR HORA',
            style: pw.TextStyle(color: cDark, fontSize: 12,
                fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        pw.Container(
          padding: const pw.EdgeInsets.all(12),
          decoration: pw.BoxDecoration(color: cLight, borderRadius: pw.BorderRadius.circular(6)),
          child: pw.Column(children: [
            _infoRow('Custo da impressora', fmt.format(p.custoImpressora), cGrey),
            _infoRow('Vida util estimada', '${p.vidaUtilHoras.toStringAsFixed(0)} h', cGrey),
            _infoRow('Formula amortizacao', 'EUR${p.custoImpressora.toStringAsFixed(0)} / ${p.vidaUtilHoras.toStringAsFixed(0)} h', cGrey),
            _infoRow('Amortizacao/hora', '${p.amortizacaoPorHora.toStringAsFixed(5)} EUR/h', cPurple),
            _infoRow('Manutencao anual', fmt.format(p.manutencaoAnual), cGrey),
            _infoRow('Horas de uso/ano', '${p.horasUsoAno.toStringAsFixed(0)} h/ano', cGrey),
            _infoRow('Manutencao/hora', '${p.manutencaoPorHora.toStringAsFixed(5)} EUR/h', cPurple),
            _infoRow('Desgaste total/hora', '${p.desgastePorHora.toStringAsFixed(5)} EUR/h', cPurple, bold: true),
            _infoRow('Custo desgaste por peca', fmt.format(p.custoDesgastePorPeca), cPurple, bold: true),
          ]),
        ),
        pw.SizedBox(height: 14),

        // ── MODELOS DE PRECIFICACAO ────────────────────────
        pw.Text('COMPARACAO DE MODELOS DE PRECIFICACAO',
            style: pw.TextStyle(color: cDark, fontSize: 12,
                fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey300, width: 0.5),
          children: [
            pw.TableRow(
              decoration: pw.BoxDecoration(color: cOrange),
              children: [_th('MODELO', PdfColors.white), _th('VALOR', PdfColors.white),
                         _th('QUANDO USAR', PdfColors.white)],
            ),
            pw.TableRow(children: [
              _td('Por Peca'),
              _tdBold(fmt.format(p.precoFinalPorPeca), cOrange),
              _td('Series, produtos definidos, lojas online'),
            ]),
            pw.TableRow(
              decoration: pw.BoxDecoration(color: cLight),
              children: [
                _td('Por Hora'),
                _tdBold('${p.precoPorHoraComMargem.toStringAsFixed(2)} EUR/h', PdfColor.fromHex('#3498DB')),
                _td('Prototipos, encomendas personalizadas'),
              ],
            ),
            pw.TableRow(children: [
              _td('Por Lote (${p.numPecas}x)'),
              _tdBold(fmt.format(p.precoFinalTotal), cGreen),
              _td('Encomendas em quantidade'),
            ]),
          ],
        ),
        pw.SizedBox(height: 16),

        // ── RODAPE ─────────────────────────────────────────
        pw.Divider(color: PdfColors.grey300),
        pw.SizedBox(height: 6),
        pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
          pw.Text('Calculadora Custo 3D',
              style: pw.TextStyle(color: cGrey, fontSize: 8)),
          pw.Text('Gerado em: ${fmtDate.format(DateTime.now())}',
              style: pw.TextStyle(color: cGrey, fontSize: 8)),
        ]),
      ],
    ));

    await Printing.sharePdf(
        bytes: await doc.save(),
        filename: '${p.nome.replaceAll(' ', '_')}_custo3d.pdf');
  }

  static String _pct(double val, double total) =>
      total > 0 ? '${(val / total * 100).toStringAsFixed(1)}%' : '0%';

  static pw.Widget _th(String text, PdfColor color) => pw.Padding(
      padding: const pw.EdgeInsets.all(6),
      child: pw.Text(text,
          style: pw.TextStyle(color: color, fontWeight: pw.FontWeight.bold, fontSize: 9)));

  static pw.Widget _td(String text) => pw.Padding(
      padding: const pw.EdgeInsets.all(6),
      child: pw.Text(text, style: const pw.TextStyle(fontSize: 9)));

  static pw.Widget _tdBold(String text, PdfColor color) => pw.Padding(
      padding: const pw.EdgeInsets.all(6),
      child: pw.Text(text,
          style: pw.TextStyle(fontSize: 9, color: color, fontWeight: pw.FontWeight.bold)));

  static pw.Widget _infoRow(String label, String value, PdfColor cor,
      {bool bold = false}) =>
      pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 2),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(label, style: const pw.TextStyle(fontSize: 9, color: PdfColors.black)),
            pw.Text(value,
                style: pw.TextStyle(
                    fontSize: 9, color: cor,
                    fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
          ],
        ),
      );
}
