
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/projeto.dart';

class AppState extends ChangeNotifier {
  Projeto atual = Projeto(id: 'novo', nome: 'Novo Projeto', data: DateTime.now());
  List<Projeto> historico = [];

  AppState() { _carregar(); }

  void atualizar(Projeto p) {
    atual = p;
    notifyListeners();
  }

  Future<void> guardar() async {
    final novo = atual.copyWith(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      data: DateTime.now(),
    );
    historico.insert(0, novo);
    if (historico.length > 30) historico = historico.sublist(0, 30);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('hist', jsonEncode(historico.map((p) => p.toJson()).toList()));
    notifyListeners();
  }

  Future<void> eliminar(String id) async {
    historico.removeWhere((p) => p.id == id);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('hist', jsonEncode(historico.map((p) => p.toJson()).toList()));
    notifyListeners();
  }

  void _carregar() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('hist');
    if (raw != null) {
      final lista = jsonDecode(raw) as List;
      historico = lista.map((e) => Projeto.fromJson(e as Map<String, dynamic>)).toList();
      notifyListeners();
    }
  }
}
